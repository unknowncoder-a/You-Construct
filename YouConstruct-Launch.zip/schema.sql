CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  role ENUM('admin','vendor','client','architect') NOT NULL,
  username VARCHAR(190) NOT NULL,
  display_name VARCHAR(190) NOT NULL,
  email VARCHAR(190) NULL,
  phone VARCHAR(60) NULL,
  password_hash VARCHAR(255) NOT NULL,
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY users_username_unique (username),
  UNIQUE KEY users_email_unique (email),
  KEY users_role_active (role, active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS vendor_profiles (
  user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  city VARCHAR(120) NULL,
  state VARCHAR(120) NULL,
  address VARCHAR(255) NULL,
  categories VARCHAR(255) NULL,
  about TEXT NULL,
  showroom_image VARCHAR(255) NULL,
  legacy_image_id VARCHAR(120) NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT vendor_profile_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  KEY vendor_city_state (city, state)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS architect_profiles (
  user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  city VARCHAR(120) NULL,
  state VARCHAR(120) NULL,
  practice VARCHAR(190) NULL,
  specialties VARCHAR(255) NULL,
  about TEXT NULL,
  website VARCHAR(255) NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT architect_profile_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  KEY architect_city_state (city, state)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS products (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  vendor_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(190) NOT NULL,
  category VARCHAR(120) NOT NULL,
  description TEXT NULL,
  price DECIMAL(12,2) NULL,
  price_note VARCHAR(80) NULL,
  unit VARCHAR(80) NULL,
  image_url VARCHAR(600) NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT product_vendor_fk FOREIGN KEY (vendor_id) REFERENCES users(id) ON DELETE CASCADE,
  KEY products_active_category (active, category),
  KEY products_vendor_active (vendor_id, active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS inquiries (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  product_id BIGINT UNSIGNED NULL,
  vendor_id BIGINT UNSIGNED NOT NULL,
  requester_id BIGINT UNSIGNED NULL,
  requester_name VARCHAR(190) NOT NULL,
  requester_email VARCHAR(190) NULL,
  requester_phone VARCHAR(60) NOT NULL,
  details TEXT NULL,
  status ENUM('new','contacted','closed') NOT NULL DEFAULT 'new',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT inquiry_vendor_fk FOREIGN KEY (vendor_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT inquiry_product_fk FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
  CONSTRAINT inquiry_requester_fk FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE SET NULL,
  KEY inquiries_vendor_status (vendor_id, status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
