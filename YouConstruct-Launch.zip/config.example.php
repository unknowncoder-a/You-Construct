<?php
// Copy this file to config.local.php and enter credentials from your hosting control panel.
return [
    'db_host' => 'localhost',
    'db_name' => 'youconstruct',
    'db_user' => 'database_user',
    'db_password' => 'database_password',
    'base_url' => '', // Leave blank when the site is installed at the domain root.
];
