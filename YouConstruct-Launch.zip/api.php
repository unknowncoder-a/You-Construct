<?php
declare(strict_types=1);
$root = __DIR__;
if (!is_file($root . '/storage/installed.lock') || !is_file($root . '/config.local.php')) {
    http_response_code(503); header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'Website setup is required. Open install.php first.']); exit;
}
$config = require $root . '/config.local.php';
date_default_timezone_set('Asia/Kolkata');
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
session_name('yc_session');
session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);
session_start();

function db(): PDO {
    static $pdo;
    global $config;
    if (!$pdo) $pdo = new PDO('mysql:host='.$config['db_host'].';dbname='.$config['db_name'].';charset=utf8mb4',
        $config['db_user'], $config['db_password'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
    return $pdo;
}
function reply($value, int $status=200): void {
    http_response_code($status); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
    echo json_encode($value,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); exit;
}
function textval($value, int $max=200): string { return trim(mb_substr((string)$value,0,$max)); }
function body(): array { $v=json_decode(file_get_contents('php://input')?:'[]',true); return is_array($v)?$v:[]; }
function currentUser(): ?array {
    if (empty($_SESSION['uid'])) return null;
    $s=db()->prepare('SELECT id,role,username,display_name,email,phone,must_change_password,active FROM users WHERE id=?');
    $s->execute([(int)$_SESSION['uid']]); $u=$s->fetch();
    if (!$u || !(int)$u['active']) { $_SESSION=[]; session_destroy(); return null; }
    return $u;
}
function needUser(?string $role=null, bool $allowPasswordChange=false): array {
    $u=currentUser();
    if (!$u) reply(['error'=>'Please sign in to continue.'],401);
    if ($role && $u['role']!==$role) reply(['error'=>'You do not have access to this area.'],403);
    if ((int)$u['must_change_password'] && !$allowPasswordChange) reply(['error'=>'Set a new password to continue.','must_change_password'=>true],403);
    return $u;
}
function checkCsrf(): void {
    $token=$_SERVER['HTTP_X_CSRF_TOKEN']??'';
    if (!$token || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'],$token)) reply(['error'=>'Your session expired. Refresh and try again.'],419);
}
function vendorRow(int $id): array {
    $s=db()->prepare('SELECT u.id,u.display_name,u.phone,u.active,p.city,p.state,p.address,p.categories,p.about,p.showroom_image,p.legacy_image_id,(SELECT COUNT(*) FROM products pr WHERE pr.vendor_id=u.id AND pr.active=1) product_count FROM users u LEFT JOIN vendor_profiles p ON p.user_id=u.id WHERE u.id=? AND u.role="vendor"');
    $s->execute([$id]); return $s->fetch()?:[];
}
try {
    $method=$_SERVER['REQUEST_METHOD']??'GET'; $action=textval($_GET['r']??'',60);
    if ($method==='GET' && !$action) {
        if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32));
        reply(['user'=>currentUser(),'csrf'=>$_SESSION['csrf']]);
    }
    if ($method==='GET' && $action==='vendors') {
        $q=textval($_GET['q']??'',120); $city=textval($_GET['city']??'',120); $state=textval($_GET['state']??'',120);
        $page=max(1,(int)($_GET['page']??1)); $limit=min(48,max(12,(int)($_GET['limit']??24)));
        $where=['u.role="vendor"','u.active=1']; $args=[];
        if ($q!=='') { $where[]='(u.display_name LIKE ? OR p.city LIKE ? OR p.state LIKE ? OR p.categories LIKE ?)'; $like='%'.$q.'%'; array_push($args,$like,$like,$like,$like); }
        if ($city!=='') { $where[]='p.city LIKE ?'; $args[]='%'.$city.'%'; }
        if ($state!=='') { $where[]='p.state LIKE ?'; $args[]='%'.$state.'%'; }
        $condition=implode(' AND ',$where);
        $c=db()->prepare("SELECT COUNT(*) FROM users u LEFT JOIN vendor_profiles p ON p.user_id=u.id WHERE $condition"); $c->execute($args); $total=(int)$c->fetchColumn();
        $s=db()->prepare("SELECT u.id,u.display_name,u.phone,p.city,p.state,p.categories,p.about,p.showroom_image,p.legacy_image_id,(SELECT COUNT(*) FROM products pr WHERE pr.vendor_id=u.id AND pr.active=1) product_count FROM users u LEFT JOIN vendor_profiles p ON p.user_id=u.id WHERE $condition ORDER BY u.display_name LIMIT $limit OFFSET ".(($page-1)*$limit));
        $s->execute($args); reply(['items'=>$s->fetchAll(),'total'=>$total,'page'=>$page,'pages'=>max(1,(int)ceil($total/$limit))]);
    }
    if ($method==='GET' && $action==='vendor') {
        $v=vendorRow((int)($_GET['id']??0)); if (!$v || !(int)$v['active']) reply(['error'=>'Vendor not found.'],404);
        $s=db()->prepare('SELECT id,title,category,description,price,price_note,unit,image_url FROM products WHERE vendor_id=? AND active=1 ORDER BY created_at DESC'); $s->execute([$v['id']]);
        reply(['vendor'=>$v,'products'=>$s->fetchAll()]);
    }
    if ($method==='GET' && $action==='products') {
        $q=textval($_GET['q']??'',120); $category=textval($_GET['category']??'',120); $page=max(1,(int)($_GET['page']??1)); $limit=48;
        $where=['pr.active=1','u.active=1']; $args=[];
        if ($q!=='') { $where[]='(pr.title LIKE ? OR pr.category LIKE ? OR u.display_name LIKE ?)'; $like='%'.$q.'%'; array_push($args,$like,$like,$like); }
        if ($category!=='' && $category!=='All') { $where[]='pr.category=?'; $args[]=$category; }
        $condition=implode(' AND ',$where); $c=db()->prepare("SELECT COUNT(*) FROM products pr JOIN users u ON u.id=pr.vendor_id WHERE $condition"); $c->execute($args); $total=(int)$c->fetchColumn();
        $s=db()->prepare("SELECT pr.id,pr.title,pr.category,pr.description,pr.price,pr.price_note,pr.unit,pr.image_url,u.id vendor_id,u.display_name vendor_name,p.city,p.state FROM products pr JOIN users u ON u.id=pr.vendor_id LEFT JOIN vendor_profiles p ON p.user_id=u.id WHERE $condition ORDER BY pr.created_at DESC LIMIT $limit OFFSET ".(($page-1)*$limit));
        $s->execute($args); reply(['items'=>$s->fetchAll(),'total'=>$total,'page'=>$page,'pages'=>max(1,(int)ceil($total/$limit))]);
    }
    if ($method==='GET' && $action==='my-products') {
        $u=needUser('vendor'); $s=db()->prepare('SELECT id,title,category,description,price,price_note,unit,image_url,active FROM products WHERE vendor_id=? ORDER BY created_at DESC'); $s->execute([$u['id']]); reply(['items'=>$s->fetchAll()]);
    }
    if ($method==='GET' && $action==='my-profile') {
        $u=needUser('vendor'); reply(['vendor'=>vendorRow((int)$u['id']),'user'=>$u]);
    }
    if ($method==='GET' && $action==='my-inquiries') {
        $u=needUser('vendor');$s=db()->prepare('SELECT i.id,i.product_id,i.requester_name,i.requester_email,i.requester_phone,i.details,i.status,i.created_at,p.title product_title FROM inquiries i LEFT JOIN products p ON p.id=i.product_id WHERE i.vendor_id=? ORDER BY i.created_at DESC LIMIT 100');$s->execute([$u['id']]);reply(['items'=>$s->fetchAll()]);
    }
    if ($method==='GET' && $action==='architects') {
        $s=db()->query('SELECT u.id,u.display_name,u.phone,a.city,a.state,a.practice,a.specialties,a.about,a.website FROM users u LEFT JOIN architect_profiles a ON a.user_id=u.id WHERE u.role="architect" AND u.active=1 ORDER BY u.display_name LIMIT 120'); reply(['items'=>$s->fetchAll()]);
    }
    if ($method==='GET' && $action==='my-architect') {
        $u=needUser('architect');$s=db()->prepare('SELECT a.city,a.state,a.practice,a.specialties,a.about,a.website FROM architect_profiles a WHERE a.user_id=?');$s->execute([$u['id']]);reply(['profile'=>$s->fetch()?:[],'user'=>$u]);
    }
    if ($method==='GET' && $action==='admin-vendors') {
        needUser('admin'); $s=db()->query('SELECT u.id,u.username,u.display_name,u.email,u.phone,u.active,u.must_change_password,p.city,p.state,p.categories,(SELECT COUNT(*) FROM products pr WHERE pr.vendor_id=u.id AND pr.active=1) product_count FROM users u LEFT JOIN vendor_profiles p ON p.user_id=u.id WHERE u.role="vendor" ORDER BY u.display_name'); reply(['items'=>$s->fetchAll()]);
    }
    if ($method==='GET' && $action==='admin-inquiries') {
        needUser('admin'); $s=db()->query('SELECT i.*,u.display_name vendor_name,p.title product_title FROM inquiries i JOIN users u ON u.id=i.vendor_id LEFT JOIN products p ON p.id=i.product_id ORDER BY i.created_at DESC LIMIT 200'); reply(['items'=>$s->fetchAll()]);
    }
    if ($method!=='POST') reply(['error'=>'This action is not available.'],404);
    checkCsrf(); $d=body();
    if ($action==='login') {
        if (!isset($_SESSION['tries'])) $_SESSION['tries']=[];
        $_SESSION['tries']=array_values(array_filter($_SESSION['tries'],fn($t)=>$t>time()-600));
        if(count($_SESSION['tries'])>=8)reply(['error'=>'Too many sign-in attempts. Wait ten minutes and try again.'],429);
        $id=textval($d['identifier']??'',190); $s=db()->prepare('SELECT * FROM users WHERE username=? OR email=? LIMIT 1'); $s->execute([$id,$id]); $u=$s->fetch();
        if(!$u || !(int)$u['active'] || !password_verify((string)($d['password']??''),$u['password_hash'])) { $_SESSION['tries'][]=time(); reply(['error'=>'The ID or password did not match.'],401); }
        session_regenerate_id(true); $_SESSION['uid']=(int)$u['id']; $_SESSION['tries']=[];
        unset($u['password_hash']); reply(['user'=>$u]);
    }
    if ($action==='register') {
        $role=textval($d['role']??'',20); if(!in_array($role,['vendor','client','architect'],true))reply(['error'=>'Choose a valid account type.'],422);
        $name=textval($d['display_name']??'',190); $email=textval($d['email']??'',190); $phone=textval($d['phone']??'',60); $pass=(string)($d['password']??'');
        if($name===''||strlen($pass)<10)reply(['error'=>'Enter a name and a password with at least 10 characters.'],422);
        if($role!=='vendor'&&!filter_var($email,FILTER_VALIDATE_EMAIL))reply(['error'=>'A valid email address is required.'],422);
        $username=$role==='vendor'?$name:$email;
        try {
            db()->beginTransaction(); $s=db()->prepare('INSERT INTO users(role,username,display_name,email,phone,password_hash) VALUES(?,?,?,?,?,?)');
            $s->execute([$role,$username,$name,$email?:null,$phone?:null,password_hash($pass,PASSWORD_DEFAULT)]); $uid=(int)db()->lastInsertId();
            if($role==='vendor') { $p=db()->prepare('INSERT INTO vendor_profiles(user_id,city,state,categories) VALUES(?,?,?,?)'); $p->execute([$uid,textval($d['city']??'',120)?:null,textval($d['state']??'',120)?:null,textval($d['categories']??'',255)?:null]); }
            if($role==='architect') { $p=db()->prepare('INSERT INTO architect_profiles(user_id,city,state,practice,specialties) VALUES(?,?,?,?,?)'); $p->execute([$uid,textval($d['city']??'',120)?:null,textval($d['state']??'',120)?:null,textval($d['practice']??'',190)?:null,textval($d['specialties']??'',255)?:null]); }
            db()->commit(); session_regenerate_id(true); $_SESSION['uid']=$uid; reply(['user'=>currentUser()]);
        } catch(PDOException $e) { if(db()->inTransaction())db()->rollBack(); if((string)$e->getCode()==='23000')reply(['error'=>'That firm name or email already has an account.'],409); throw $e; }
    }
    if ($action==='logout') { $_SESSION=[]; session_destroy(); reply(['ok'=>true]); }
    if ($action==='password') {
        $u=needUser(null,true); $pass=(string)($d['password']??''); if(strlen($pass)<10)reply(['error'=>'Use at least 10 characters for your new password.'],422);
        db()->prepare('UPDATE users SET password_hash=?,must_change_password=0 WHERE id=?')->execute([password_hash($pass,PASSWORD_DEFAULT),$u['id']]); reply(['user'=>currentUser()]);
    }
    if ($action==='profile') {
        $u=needUser('vendor'); $name=textval($d['display_name']??'',190); $email=textval($d['email']??'',190); if($name==='')reply(['error'=>'Firm name is required.'],422);
        if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL))reply(['error'=>'Enter a valid email address.'],422);
        try {
            db()->prepare('UPDATE users SET username=?,display_name=?,email=?,phone=? WHERE id=?')->execute([$name,$name,$email?:null,textval($d['phone']??'',60)?:null,$u['id']]);
            db()->prepare('UPDATE vendor_profiles SET city=?,state=?,address=?,categories=?,about=? WHERE user_id=?')->execute([textval($d['city']??'',120)?:null,textval($d['state']??'',120)?:null,textval($d['address']??'',255)?:null,textval($d['categories']??'',255)?:null,textval($d['about']??'',4000)?:null,$u['id']]);
        } catch(PDOException $e) { if((string)$e->getCode()==='23000')reply(['error'=>'That firm name or email is already in use.'],409); throw $e; }
        reply(['user'=>currentUser(),'vendor'=>vendorRow((int)$u['id'])]);
    }
    if ($action==='architect-profile') {
        $u=needUser('architect');$name=textval($d['display_name']??'',190);if($name==='')reply(['error'=>'Your name is required.'],422);
        $email=textval($d['email']??'',190);if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL))reply(['error'=>'Enter a valid email address.'],422);
        $website=textval($d['website']??'',255);$scheme=strtolower((string)parse_url($website,PHP_URL_SCHEME));if($website!==''&&(!filter_var($website,FILTER_VALIDATE_URL)||!in_array($scheme,['http','https'],true)))reply(['error'=>'Use a web address that starts with http:// or https://.'],422);
        try {
          db()->prepare('UPDATE users SET display_name=?,email=?,phone=? WHERE id=?')->execute([$name,$email?:null,textval($d['phone']??'',60)?:null,$u['id']]);
          db()->prepare('UPDATE architect_profiles SET city=?,state=?,practice=?,specialties=?,about=?,website=? WHERE user_id=?')->execute([textval($d['city']??'',120)?:null,textval($d['state']??'',120)?:null,textval($d['practice']??'',190)?:null,textval($d['specialties']??'',255)?:null,textval($d['about']??'',4000)?:null,$website?:null,$u['id']]);
        } catch(PDOException $e) { if((string)$e->getCode()==='23000')reply(['error'=>'That email address is already used.'],409);throw $e; }
        reply(['user'=>currentUser()]);
    }
    if ($action==='showroom') {
        $u=needUser('vendor'); if(empty($_FILES['photo'])||$_FILES['photo']['error']!==UPLOAD_ERR_OK)reply(['error'=>'Choose a showroom photo.'],422);
        $f=$_FILES['photo']; if($f['size']>5*1024*1024)reply(['error'=>'Showroom photos must be 5 MB or smaller.'],413);
        $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']); $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??null;$dimensions=@getimagesize($f['tmp_name']);
        if(!$ext||!$dimensions||$dimensions[0]>8000||$dimensions[1]>8000||($dimensions[0]*$dimensions[1])>25000000)reply(['error'=>'Use a JPG, PNG or WebP photo up to 8,000 pixels wide or tall.'],415);
        $dir=$root.'/uploads'; if(!is_dir($dir)&&!mkdir($dir,0755,true))reply(['error'=>'Photo storage is unavailable.'],500);
        $file=bin2hex(random_bytes(18)).'.'.$ext; if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$file))reply(['error'=>'Could not save the photo. Check uploads folder permissions.'],500);
        $old=db()->prepare('SELECT showroom_image FROM vendor_profiles WHERE user_id=?');$old->execute([$u['id']]);$old=$old->fetchColumn();
        db()->prepare('UPDATE vendor_profiles SET showroom_image=? WHERE user_id=?')->execute(['uploads/'.$file,$u['id']]);
        if($old&&str_starts_with($old,'uploads/')&&is_file($root.'/'.$old))@unlink($root.'/'.$old);
        reply(['vendor'=>vendorRow((int)$u['id'])]);
    }
    if ($action==='product-save') {
        $u=needUser('vendor'); $id=(int)($d['id']??0); $title=textval($d['title']??'',190); $cat=textval($d['category']??'',120);
        $desc=textval($d['description']??'',3000); $unit=textval($d['unit']??'',80); $note=textval($d['price_note']??'',80); $image=textval($d['image_url']??'',600);
        if($title===''||$cat==='')reply(['error'=>'Product name and category are required.'],422);
        $raw=str_replace([',','₹',' '],'',(string)($d['price']??'')); $price=$raw===''?null:filter_var($raw,FILTER_VALIDATE_FLOAT);
        if($raw!==''&&($price===false||$price<0))reply(['error'=>'Enter a valid price or leave it blank.'],422);
        if($image!==''&&!filter_var($image,FILTER_VALIDATE_URL))reply(['error'=>'Product image must be a full web address.'],422);
        $imageScheme=strtolower((string)parse_url($image,PHP_URL_SCHEME));if($image!==''&&(!filter_var($image,FILTER_VALIDATE_URL)||!in_array($imageScheme,['http','https'],true)))reply(['error'=>'Product images must use an http:// or https:// address.'],422);
        if($id) { $exists=db()->prepare('SELECT id FROM products WHERE id=? AND vendor_id=?');$exists->execute([$id,$u['id']]);if(!$exists->fetchColumn())reply(['error'=>'Product not found.'],404);$s=db()->prepare('UPDATE products SET title=?,category=?,description=?,price=?,price_note=?,unit=?,image_url=? WHERE id=? AND vendor_id=?');$s->execute([$title,$cat,$desc?:null,$price,$note?:null,$unit?:null,$image?:null,$id,$u['id']]); }
        else { $s=db()->prepare('INSERT INTO products(vendor_id,title,category,description,price,price_note,unit,image_url) VALUES(?,?,?,?,?,?,?,?)');$s->execute([$u['id'],$title,$cat,$desc?:null,$price,$note?:null,$unit?:null,$image?:null]);$id=(int)db()->lastInsertId(); }
        $s=db()->prepare('SELECT id,title,category,description,price,price_note,unit,image_url,active FROM products WHERE id=?');$s->execute([$id]);reply(['product'=>$s->fetch()]);
    }
    if ($action==='product-delete') { $u=needUser('vendor'); db()->prepare('UPDATE products SET active=0 WHERE id=? AND vendor_id=?')->execute([(int)($d['id']??0),$u['id']]); reply(['ok'=>true]); }
    if ($action==='inquiry') {
        $vid=(int)($d['vendor_id']??0);$pid=(int)($d['product_id']??0);$name=textval($d['name']??'',190);$phone=textval($d['phone']??'',60);$email=textval($d['email']??'',190);
        if(!$vid||$name===''||$phone==='')reply(['error'=>'Name and phone number are required.'],422);
        $s=db()->prepare('SELECT id FROM users WHERE id=? AND role="vendor" AND active=1');$s->execute([$vid]);if(!$s->fetchColumn())reply(['error'=>'Vendor not found.'],404);
        if($pid){$s=db()->prepare('SELECT id FROM products WHERE id=? AND vendor_id=? AND active=1');$s->execute([$pid,$vid]);if(!$s->fetchColumn())$pid=0;}
        $u=currentUser();$s=db()->prepare('INSERT INTO inquiries(product_id,vendor_id,requester_id,requester_name,requester_email,requester_phone,details) VALUES(?,?,?,?,?,?,?)');
        $s->execute([$pid?:null,$vid,$u['id']??null,$name,$email?:null,$phone,textval($d['details']??'',3000)?:null]);reply(['ok'=>true,'message'=>'Your request has been sent.']);
    }
    if ($action==='admin-vendor-create') {
        needUser('admin');$name=textval($d['display_name']??'',190);$pass=(string)($d['password']??'');$email=textval($d['email']??'',190);
        if($name===''||strlen($pass)<10)reply(['error'=>'Enter the firm name and a password with at least 10 characters.'],422);
        if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL))reply(['error'=>'Enter a valid email address.'],422);
        try {
            db()->beginTransaction();$s=db()->prepare('INSERT INTO users(role,username,display_name,email,phone,password_hash,must_change_password) VALUES("vendor",?,?,?,?,?,1)');
            $s->execute([$name,$name,$email?:null,textval($d['phone']??'',60)?:null,password_hash($pass,PASSWORD_DEFAULT)]);$vid=(int)db()->lastInsertId();
            db()->prepare('INSERT INTO vendor_profiles(user_id,city,state,categories) VALUES(?,?,?,?)')->execute([$vid,textval($d['city']??'',120)?:null,textval($d['state']??'',120)?:null,textval($d['categories']??'',255)?:null]);
            db()->commit();reply(['vendor'=>vendorRow($vid)]);
        } catch(PDOException $e) { if(db()->inTransaction())db()->rollBack();if((string)$e->getCode()==='23000')reply(['error'=>'A vendor already uses this firm name or email.'],409);throw $e; }
    }
    if ($action==='admin-vendor-toggle') { needUser('admin');db()->prepare('UPDATE users SET active=IF(active=1,0,1) WHERE id=? AND role="vendor"')->execute([(int)($d['id']??0)]);reply(['ok'=>true]); }
    if ($action==='admin-vendor-reset') { needUser('admin');$id=(int)($d['id']??0);$pass=(string)($d['password']??'');if(strlen($pass)<10)reply(['error'=>'Use a temporary password with at least 10 characters.'],422);$s=db()->prepare('UPDATE users SET password_hash=?,must_change_password=1 WHERE id=? AND role="vendor"');$s->execute([password_hash($pass,PASSWORD_DEFAULT),$id]);reply(['ok'=>true]); }
    if ($action==='admin-inquiry-status') { needUser('admin');$status=textval($d['status']??'',20);if(!in_array($status,['new','contacted','closed'],true))reply(['error'=>'Choose a valid status.'],422);db()->prepare('UPDATE inquiries SET status=? WHERE id=?')->execute([$status,(int)($d['id']??0)]);reply(['ok'=>true]); }
    reply(['error'=>'This action is not available.'],404);
} catch(Throwable $e) {
    error_log('[You Construct] '.$e->getMessage());
    reply(['error'=>'Something went wrong while saving your request. Please try again.'],500);
}
