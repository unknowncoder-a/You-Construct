# You Construct launch package

This is the server-backed version of the You Construct website. It is designed for a shared hosting account that supports PHP and MySQL/MariaDB. It includes the existing 365-vendor directory and 16 featured products; the installer also creates a vendor profile if an imported product seller is not already in the directory.

## Included

- Public product catalog with category and product search.
- Vendor directory searchable by vendor name, city and state, with pagination and public store pages.
- Before database setup, the public catalog can still show the bundled vendor and product data in read-only preview mode.
- Separate client, architect and vendor accounts.
- Existing vendor sign-in using the firm's name as the ID. The shared starter password is used only during installation; vendors must choose a personal password at first sign-in.
- Vendor workspace for editing public profile details, uploading a showroom photo, and creating, editing or removing product listings.
- Product and vendor changes are saved in MySQL and appear in the public directory after saving.
- Project enquiries saved to the database and visible to the relevant vendor and the site administrator.
- Administrator access to create and deactivate vendor accounts, reset vendor access with a temporary password, and manage enquiry status.

The site provides a product enquiry flow. It does not take online payments or place paid orders; add a payment provider before advertising checkout.

## Hosting requirements

Ask your current hosting provider whether the account has:

- PHP 8.1 or newer with PDO MySQL, fileinfo, mbstring and iconv.
- MySQL 5.7+ or MariaDB 10.4+.
- HTTPS enabled for the domain.
- PHP write access to the storage/ and uploads/ folders.
- Apache .htaccess support (typical on cPanel hosting). If the host uses Nginx, ask the provider to protect config.local.php, data/ and storage/, and block executable files in uploads/.

## Install on your current host

1. Back up the current website files and database before replacing anything. If possible, install this package on a temporary subdomain first.
2. Upload the ZIP contents to the folder for the domain or subdomain. Keep the assets/, data/, storage/ and uploads/ folders together with index.php, api.php, schema.sql and install.php. Keep hidden .htaccess files.
3. In your hosting panel, create a MySQL database and database user. Grant the user full privileges to that database.
4. Visit https://your-domain.example/install.php. Enter the database details, a unique administrator name/email/password, and the one-time starter password you specified earlier for the existing vendors. The shared starter password is hashed for each vendor and is not stored in the website files.
5. When setup finishes, use the administrator email and password to sign in from the person icon in the site header. Existing vendors sign in from the “Vendor sign in” link, using their firm name and the starter password. They are required to set a new password before accessing their workspace.
6. Confirm that the domain uses HTTPS. After installation, the setup page is locked. You can also remove install.php from the host once setup has completed.

Do not put database credentials or a live password in this README or in a public folder. The one-time setup writes database access to config.local.php; the included Apache rules block public access to that file.

## Files

- index.php — website entry point.
- install.php — one-time database setup and vendor import.
- api.php — account, vendor, product and enquiry services.
- schema.sql — database structure.
- data/vendors.json and data/products.json — imported public directory and featured catalog.
- assets/ — logo, styles and website scripts.
- uploads/ — vendor showroom photo storage.
- storage/ — one-time installation lock.

The project workspace does not have PHP installed, so I could not run the hosted PHP pages here. The public launch link is created after you upload this package to the current host and connect it to your domain. This package does not include hosting or domain access.

