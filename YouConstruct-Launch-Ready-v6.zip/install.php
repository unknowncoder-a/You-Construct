<?php
declare(strict_types=1);
$root=__DIR__; $lock=$root.'/storage/installed.lock';
session_name('yc_installer'); session_set_cookie_params(['httponly'=>true,'samesite'=>'Strict','secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off']); session_start();
if(is_file($lock)){http_response_code(404);echo 'Setup is already complete.';exit;}
if(empty($_SESSION['setup_csrf']))$_SESSION['setup_csrf']=bin2hex(random_bytes(32));
$error='';$done=false;
if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
  if(!hash_equals($_SESSION['setup_csrf'],(string)($_POST['csrf']??''))){$error='This setup page expired. Refresh and try again.';}
  else{
    $host=trim((string)($_POST['db_host']??'localhost'));$dbname=trim((string)($_POST['db_name']??''));$dbuser=trim((string)($_POST['db_user']??''));$dbpass=(string)($_POST['db_password']??'');
    $adminName=trim((string)($_POST['admin_name']??''));$adminEmail=trim((string)($_POST['admin_email']??''));$adminPass=(string)($_POST['admin_password']??'');$legacyPass=(string)($_POST['legacy_password']??'');
    if($dbname===''||$dbuser===''||$adminName===''||!filter_var($adminEmail,FILTER_VALIDATE_EMAIL)||strlen($adminPass)<12||strlen($legacyPass)<10){$error='Complete each required field. Admin passwords need at least 12 characters; the initial vendor password needs at least 10.';}
    else{
      try{
        $pdo=new PDO('mysql:host='.$host.';dbname='.$dbname.';charset=utf8mb4',$dbuser,$dbpass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
        $schema=file_get_contents($root.'/schema.sql');
        foreach(preg_split('/;\s*(?:\r?\n|$)/',trim($schema)) as $statement){if(trim($statement)!=='')$pdo->exec($statement);}
        $pdo->beginTransaction();
        $a=$pdo->prepare('SELECT id FROM users WHERE username=? OR email=? LIMIT 1');$a->execute([$adminEmail,$adminEmail]);
        if(!$a->fetchColumn()){
          $a=$pdo->prepare('INSERT INTO users(role,username,display_name,email,password_hash) VALUES("admin",?,?,?,?)');
          $a->execute([$adminEmail,$adminName,$adminEmail,password_hash($adminPass,PASSWORD_DEFAULT)]);
        }
        $vendors=json_decode(file_get_contents($root.'/data/vendors.json'),true,512,JSON_THROW_ON_ERROR);
        $legacyHash=password_hash($legacyPass,PASSWORD_DEFAULT);
        $keyOf=function($s){$ascii=@iconv('UTF-8','ASCII//TRANSLIT//IGNORE',(string)$s);return strtolower(preg_replace('/[^a-z0-9]/','',$ascii===false?(string)$s:$ascii));};
        $vendorIds=[];
        $find=$pdo->prepare('SELECT id FROM users WHERE username=? LIMIT 1');
        $add=$pdo->prepare('INSERT INTO users(role,username,display_name,phone,password_hash,must_change_password) VALUES("vendor",?,?,?,?,1)');
        $profile=$pdo->prepare('INSERT INTO vendor_profiles(user_id,city,state,legacy_image_id) VALUES(?,?,?,?)');
        foreach($vendors as $row){
          $firm=trim((string)($row['name']??'')); if($firm==='')continue;
          $find->execute([$firm]);$uid=(int)$find->fetchColumn();
          if(!$uid){$add->execute([$firm,$firm,($row['phone']??'')?:null,$legacyHash]);$uid=(int)$pdo->lastInsertId();$profile->execute([$uid,($row['city']??'')?:null,($row['state']??'')?:null,($row['image']??'')?:null]);}
          $vendorIds[$keyOf($firm)]=$uid;
        }
        $products=json_decode(file_get_contents($root.'/data/products.json'),true,512,JSON_THROW_ON_ERROR);
        $productFind=$pdo->prepare('SELECT id FROM products WHERE vendor_id=? AND title=? LIMIT 1');
        $productAdd=$pdo->prepare('INSERT INTO products(vendor_id,title,category,description,price,image_url,active) VALUES(?,?,?,?,?,?,1)');
        foreach($products as $item){
          $firm=trim((string)($item['vendorName']??''));if($firm==='')continue;$key=$keyOf($firm);$uid=$vendorIds[$key]??0;
          if(!$uid){$find->execute([$firm]);$uid=(int)$find->fetchColumn();if(!$uid){$add->execute([$firm,$firm,null,$legacyHash]);$uid=(int)$pdo->lastInsertId();$profile->execute([$uid,null,null,null]);}$vendorIds[$key]=$uid;}
          $title=trim((string)($item['title']??''));if($title==='')continue;
          $productFind->execute([$uid,$title]);if($productFind->fetchColumn())continue;
          $price=($item['price']??'')!==''?(float)$item['price']:null;
          $productAdd->execute([$uid,$title,($item['category']??'Other'),($item['description']??'')?:null,$price,($item['image']??'')?:null]);
        }
        $pdo->commit();
        $config=['db_host'=>$host,'db_name'=>$dbname,'db_user'=>$dbuser,'db_password'=>$dbpass,'base_url'=>''];
        $configText="<?php\nreturn ".var_export($config,true).";\n";
        if(file_put_contents($root.'/config.local.php',$configText,LOCK_EX)===false)throw new RuntimeException('Could not save the website database configuration.');
        @chmod($root.'/config.local.php',0640);
        if(file_put_contents($lock,"installed ".gmdate('c'),LOCK_EX)===false)throw new RuntimeException('Could not finish the installation lock.');
        @chmod($lock,0640);$done=true;
      }catch(Throwable $e){if(isset($pdo)&&$pdo->inTransaction())$pdo->rollBack();error_log('[You Construct setup] '.$e->getMessage());$error='Setup could not complete. Check the database details and make sure the database user can create tables. Then try again.';}
    }
  }
}
function esc($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Install · You Construct</title><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet"><style>
*{box-sizing:border-box}body{margin:0;background:#f6f4ef;color:#252c27;font:14px "DM Sans",sans-serif}.page{width:min(780px,calc(100% - 32px));margin:45px auto}.brand{display:flex;align-items:center;gap:13px;color:#442d21;font:800 23px Manrope}.brand img{width:150px}.card{background:#fff;border:1px solid #e7e4dd;border-radius:10px;padding:30px;margin-top:22px;box-shadow:0 18px 45px #242d2510}.kicker{color:#9a674f;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;font-weight:700}.card h1{font:700 29px Manrope;letter-spacing:-1px;margin:10px 0}.intro{color:#69726b;line-height:1.65;margin:0 0 24px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:15px}.group{border-top:1px solid #eeeae3;padding-top:18px;margin-top:12px}.group h2{font:700 16px Manrope;margin:0 0 13px}.field label{display:block;font-size:11px;font-weight:700;margin:0 0 6px}.field input{width:100%;border:1px solid #dcd8cf;border-radius:5px;padding:12px;font:13px "DM Sans";background:#fff}.wide{grid-column:1/-1}.hint{font-size:11px;color:#7a817a;line-height:1.5;margin-top:6px}.btn{border:0;border-radius:4px;background:#b9674e;color:#fff;padding:13px 18px;font:700 13px "DM Sans";cursor:pointer;margin-top:20px}.notice{border-radius:5px;background:#f9ece6;color:#854934;padding:12px 14px;line-height:1.5;margin-bottom:18px}.success{background:#edf3e9;color:#31523a}.foot{color:#778078;font-size:11px;line-height:1.7;margin:16px 2px}@media(max-width:600px){.page{margin:20px auto}.card{padding:21px}.grid{grid-template-columns:1fr}.wide{grid-column:auto}}
</style></head><body><main class="page"><div class="brand"><img src="assets/you-construct.webp" alt="You Construct"><span>Website setup</span></div><section class="card"><div class="kicker">One-time installation</div><h1><?= $done?'Your website is ready to upload':'Connect You Construct to your hosting' ?></h1><p class="intro"><?= $done?'Setup is complete. Sign in as the website administrator or open the vendor directory. Imported vendors must choose a new personal password when they first sign in.':'Enter the database information from your hosting panel. This setup will create the site tables, secure the administrator account, and import the full vendor directory.' ?></p>
<?php if($error): ?><div class="notice"><?=esc($error)?></div><?php endif; ?>
<?php if($done): ?><div class="notice success">Imported the vendor directory and existing product listings. The shared vendor starter password is saved only as password hashes. <a href="index.php">Open You Construct ↗</a> · <a href="index.php?page=vendor-login" target="_blank" rel="noopener">Open vendor sign in in a new tab ↗</a></div><?php else: ?>
<form method="post" autocomplete="off"><input type="hidden" name="csrf" value="<?=esc($_SESSION['setup_csrf'])?>">
<div class="group"><h2>MySQL database</h2><div class="grid"><div class="field"><label for="db_host">Database host</label><input id="db_host" name="db_host" value="<?=esc($_POST['db_host']??'localhost')?>" required></div><div class="field"><label for="db_name">Database name</label><input id="db_name" name="db_name" value="<?=esc($_POST['db_name']??'')?>" required></div><div class="field"><label for="db_user">Database username</label><input id="db_user" name="db_user" value="<?=esc($_POST['db_user']??'')?>" required></div><div class="field"><label for="db_password">Database password</label><input id="db_password" name="db_password" type="password" required></div></div></div>
<div class="group"><h2>Administrator profile</h2><div class="grid"><div class="field"><label for="admin_name">Administrator name</label><input id="admin_name" name="admin_name" value="<?=esc($_POST['admin_name']??'')?>" required></div><div class="field"><label for="admin_email">Administrator email / sign-in ID</label><input id="admin_email" name="admin_email" type="email" value="<?=esc($_POST['admin_email']??'')?>" required></div><div class="field wide"><label for="admin_password">Administrator password</label><input id="admin_password" name="admin_password" type="password" minlength="12" required><div class="hint">Use a unique password of at least 12 characters. The site does not set a public default administrator password.</div></div></div></div>
<div class="group"><h2>Existing vendor accounts</h2><div class="grid"><div class="field wide"><label for="legacy_password">One-time shared starter password for imported vendors</label><input id="legacy_password" name="legacy_password" type="password" minlength="10" required><div class="hint">Existing firm names are used as sign-in IDs. Vendors are required to replace this shared starter password at first sign-in.</div></div></div></div>
<button class="btn">Install You Construct</button></form><p class="foot">This creates the account system and shared directory on your hosting. Keep the website folder and database backed up. Installation is locked after setup completes.</p><?php endif; ?></section></main></body></html>
